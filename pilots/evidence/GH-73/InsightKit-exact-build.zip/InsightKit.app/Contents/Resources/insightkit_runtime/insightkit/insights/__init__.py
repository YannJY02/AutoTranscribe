"""Insight generation modules."""
